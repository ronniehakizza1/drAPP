import 'package:flutter/material.dart';

const Color primary = Color.fromARGB(255, 0, 101, 251);
const Color grey = Color.fromARGB(255, 231, 231, 231);
const Color greyLight = Color.fromARGB(255, 249, 249, 249);
