# Medical App Group Project

An App for simple health monitoring and treatment.
The mobile app interfaces with a Firebase backend to manage patient and doctor interactions

## Usage

How to use

- Open the App
- Log in or Sign up
- Make a simple lung test
- Get results
- Get the recommended action
- Schedule an appointment with a doctor if necessary
