# Web and Mobile App Group Project

This is a combination of a Web and Mobile Medical application

## The Web Version

![Webpage](./WebScreen.png)

## The Mobile Version

<p float="left">
  <img src="./Mobile/medical_app/Screenshot_1703263831.png" width="200" />
  <img src="./Mobile/medical_app/test_lung.png" width="200" /> 
  <img src="./Mobile/medical_app/dash.png" width="200" />
</p>
